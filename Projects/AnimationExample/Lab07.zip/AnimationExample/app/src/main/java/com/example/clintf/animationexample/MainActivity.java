package com.example.clintf.animationexample;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

/**
 * the main Activity for the AnimationExample
 *
 * @author Carleton Fuhs
 * @date 4/05/2017
 * @email cafuhs@coastal.edu
 * @course CSCI 343
 */
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
